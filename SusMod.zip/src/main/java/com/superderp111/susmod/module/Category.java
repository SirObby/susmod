package com.superderp111.susmod.module;

public enum Category {
    PLAYER, PLOTS, CODE, BUILD, SETTINGS
}
