package com.superderp111.susmod.util;

public interface ILoader {
    void load() throws NoSuchFieldException, IllegalAccessException;
}
