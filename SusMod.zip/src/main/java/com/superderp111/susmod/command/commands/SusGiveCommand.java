package com.superderp111.susmod.command.commands;

import com.google.common.collect.Lists;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.superderp111.susmod.SusMod;
import com.superderp111.susmod.command.Command;
import com.superderp111.susmod.server.Client;
import com.superderp111.susmod.util.ChatUtil;
import net.fabricmc.fabric.api.client.command.v1.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v1.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.argument.ItemStackArgument;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.util.collection.DefaultedList;
import org.apache.commons.lang3.reflect.FieldUtils;

public class SusGiveCommand extends Command {
    @Override
    public void register(MinecraftClient mc, CommandDispatcher<FabricClientCommandSource> cd) throws IllegalAccessException {
        LiteralCommandNode node = registerMain(cd);
        Object aliasCmd = cd.register(LiteralArgumentBuilder.literal("sg"));
        FieldUtils.writeField(aliasCmd, "redirect", node, true);
    }

    public LiteralCommandNode registerMain(CommandDispatcher cd) {
        return cd.register(ClientCommandManager.literal("susgive")
                .then(ClientCommandManager.argument("item", ItemStackArgumentType.itemStack())
                        .then(ClientCommandManager.argument("count", IntegerArgumentType.integer())
                                .executes(ctx -> {
                                    giveItem(MinecraftClient.getInstance(), ctx.getArgument("item", ItemStackArgument.class)
                                                    .createStack(1, false),
                                            ctx.getArgument("count", Integer.class));
                                    return 1;
                                })
                        )
                        .executes(ctx -> {
                            giveItem(MinecraftClient.getInstance(), ctx.getArgument("item", ItemStackArgument.class)
                                    .createStack(1, false), 1);
                            return 1;
                        })
                ));
    }

    private void giveItem(MinecraftClient mc, ItemStack item, int count) {
        item.setCount(count);
        if (MinecraftClient.getInstance().player.isCreative()) {
            if (count >= 1) {
                if (count <= item.getMaxCount()) {
                    giveCreativeItem(item, true);
                } else {
                    LiteralText text1 = new LiteralText("Maximum item count for ");
                    LiteralText text2 = new LiteralText(" is " + item.getMaxCount() + "!");
                    ChatUtil.sendMessage(text1.append(item.getName()).append(text2).toString());
                }
            } else {
                ChatUtil.sendMessage("Minimum item count is 1!");
            }
        }
    }

    public static void giveCreativeItem(ItemStack item, boolean preferHand) {
        MinecraftClient mc = MinecraftClient.getInstance();
        DefaultedList<ItemStack> mainInventory = mc.player.getInventory().main;

        if (preferHand) {
            if (mc.player.getMainHandStack().isEmpty()) {
                mc.interactionManager.clickCreativeStack(item, mc.player.getInventory().selectedSlot + 36);
                return;
            }
        }

        for (int index = 0; index < mainInventory.size(); index++) {
            ItemStack i = mainInventory.get(index);
            ItemStack compareItem = i.copy();
            compareItem.setCount(item.getCount());
            if (item == compareItem) {
                while (i.getCount() < i.getMaxCount() && item.getCount() > 0) {
                    i.setCount(i.getCount() + 1);
                    item.setCount(item.getCount() - 1);
                }
            } else {
                if (i.getItem() == Items.AIR) {
                    if (index < 9)
                        MinecraftClient.getInstance().interactionManager.clickCreativeStack(item, index + 36);
                    mainInventory.set(index, item);
                    return;
                }
            }
        }
    }
}
